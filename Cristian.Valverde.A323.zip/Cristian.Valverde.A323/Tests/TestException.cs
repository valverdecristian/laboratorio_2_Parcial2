using Entidades;

namespace Tests
{
    [TestClass]
    public class TestException
    {
        [TestMethod]
        [ExpectedException(typeof(BackLogException))]
        public void Serializadora_GuardarXML_DeberiaLanzarBackLogException()
        {
            string ruta = "";

            Serializadora serializadora = new Serializadora();
            List<Serie> series = new List<Serie>
            {
                new Serie("Serie1", "Genero1")
            };

            serializadora.Guardar(series, ruta);
        }

        [TestMethod]
        [ExpectedException(typeof(BackLogException))]
        public void Serializadora_GuardarJSON_DeberiaLanzarBackLogException()
        {
            string ruta = "";

            Serializadora serializadora = new Serializadora();
            List<Serie> series = new List<Serie>
            {
                new Serie("Serie1", "Genero1")
            };

            ((IGuardar<List<Serie>>)serializadora).Guardar(series, ruta);
        }
    }
}