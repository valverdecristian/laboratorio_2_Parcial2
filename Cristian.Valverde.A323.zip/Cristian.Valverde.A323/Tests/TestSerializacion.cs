using Entidades;

namespace Tests
{
    [TestClass]
    public class TestSerializacion
    {
        private Serializadora serializadora;
        private List<Serie> series;

        [TestInitialize]
        public void Setup()
        {
            serializadora = new Serializadora();
            series = new List<Serie>
            {
                new Serie("Serie1", "Genero1"),
                new Serie("Serie2", "Genero2")
            };
        }

        [TestMethod]
        public void GuardarXML_DeberiaGuardarEnFormatoXML()
        {
            string ruta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "series.xml");

            serializadora.Guardar(series, ruta);

            Assert.IsTrue(File.Exists(ruta));

            string contenido = File.ReadAllText(ruta);
            Assert.IsTrue(contenido.Contains("Serie1"));
            Assert.IsTrue(contenido.Contains("Genero1"));
        }

        [TestMethod]
        public void GuardarJSON_DeberiaGuardarEnFormatoJSON()
        {
            string ruta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "series.json");

            ((IGuardar<List<Serie>>)serializadora).Guardar(series, ruta);

            Assert.IsTrue(File.Exists(ruta));

            string contenido = File.ReadAllText(ruta);
            Assert.IsTrue(contenido.Contains("Serie1"));
            Assert.IsTrue(contenido.Contains("Genero1"));
        }
    }
}