﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class AccesoDatos
    {
        static SqlCommand comando;
        static SqlConnection conexion;

        static AccesoDatos()
        {
            conexion = new SqlConnection("Server=.;Database=20240701-SP;Trusted_Connection=True;");
            comando = new SqlCommand();
            comando.CommandType = CommandType.Text;
            comando.Connection = conexion;
        }

        public static void ActualizarSerie(Serie item)
        {
            try
            {
                conexion.Open();
                comando.CommandText = "UPDATE dbo.series SET alumno = @alumno WHERE nombre = @nombre";
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@alumno", "Cristian Valverde");
                comando.Parameters.AddWithValue("@nombre", item.Nombre);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.Log($"Error al actualizar la serie: {ex.Message}");
                throw new BackLogException("Error al actualizar la serie", ex);
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        public static List<Serie> ObtenerBacklog()
        {
            List<Serie> series = new List<Serie>();

            try
            {
                conexion.Open();
                comando.CommandText = "SELECT * FROM dbo.series";

                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        string nombre = dataReader["nombre"].ToString();
                        string genero = dataReader["genero"].ToString();
                        series.Add(new Serie(nombre, genero));
                    }
                }

                return series;
            }
            catch (Exception e)
            {
                Logger.Log($"Error al obtener el backlog: {e.Message}");
                throw new BackLogException("Error al obtener el backlog", e);
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }


    }
}
