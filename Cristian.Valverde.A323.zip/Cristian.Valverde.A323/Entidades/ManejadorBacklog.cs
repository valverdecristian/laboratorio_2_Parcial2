﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoBacklog(Serie serie);
    
    public class ManejadorBacklog
    {
        public event DelegadoBacklog serieParaVer;

        public void IniciarManejador(List<Serie> series)
        {
            Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series)
        {
            try
            {
                while (true)
                {
                    Serie serie;

                    lock (series)
                    {
                        if (series.Count == 0) break;
                        int index = series.GenerarRandom();
                        serie = series[index];
                    }

                    AccesoDatos.ActualizarSerie(serie);

                    Thread.Sleep(1500);

                    if (serieParaVer != null)
                    {
                        serieParaVer.Invoke(serie);
                    }

                    lock (series)
                    {
                        series.Remove(serie);
                    }
                }
            }
            catch (ArgumentOutOfRangeException ex)
            {
                throw new BackLogException("Error al mover series: Índice fuera de rango", ex);
            }
            catch (Exception ex)
            {
                Logger.Log($"Error en MoverSeries: {ex.Message}");
                throw new BackLogException("Error al mover series", ex);
            }
        }
    }
}
