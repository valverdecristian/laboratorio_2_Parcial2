﻿using System.Runtime.Serialization;
using System.Text.Json;
using System.Xml.Serialization;

namespace Entidades
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        public void Guardar(List<Serie> item, string ruta)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Serie>));
                using (StreamWriter writer = new StreamWriter(ruta))
                {
                    serializer.Serialize(writer, item);
                }
            }
            catch (Exception e)
            {
                throw new BackLogException("Error al guardar en formato XML", e);
            }
        }

        void IGuardar<List<Serie>>.Guardar(List<Serie> item, string ruta)
        {
            try
            {
                string jsonString = JsonSerializer.Serialize(item);
                File.WriteAllText(ruta, jsonString);
            }
            catch (Exception e)
            {
                throw new BackLogException("Error al guardar en formato JSON", e);
            }
        }
    }
}