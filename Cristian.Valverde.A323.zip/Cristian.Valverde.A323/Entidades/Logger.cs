﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class Logger
    {
        public static void Log(string mensaje)
        {
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "log.txt");
            string logMessage = $"{DateTime.Now}: {mensaje}{Environment.NewLine}";

            try
            {
                File.AppendAllText(path, logMessage);
            }
            catch (Exception e)
            {
                throw new BackLogException($"Error al escribir el log: {e}");
            }
        }
    }
}
